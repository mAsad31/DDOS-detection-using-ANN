import os
from random import randint
import time
import errno

FIFO = 'flowpipe'

try:
    os.mkfifo(FIFO)
except OSError as oe: 
    if oe.errno != errno.EEXIST:
        raise

print("Opening FIFO...")
with open(FIFO, 'w') as fifo:
    print("FIFO opened")
    while True:
        fifo.write(str(randint(0, 100)) + '\t' + str(randint(0, 100)))
        fifo.flush()
        print('written')
        time.sleep(5)
