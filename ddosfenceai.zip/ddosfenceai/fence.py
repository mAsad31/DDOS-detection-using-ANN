import argparse
import time
import sys
from watchdog.observers import Observer
from watchdog.events import PatternMatchingEventHandler
import re
import numpy as np
import json
import gzip
import os
import pandas as pd
import subprocess
import errno

from sklearn.model_selection import train_test_split
from keras import backend as K
from keras.utils import np_utils
from sklearn.preprocessing import *
from keras.models import Sequential
from keras.callbacks import ModelCheckpoint, TensorBoard
from keras.layers import Dense, Activation, Flatten, Dropout
from keras.layers.normalization import BatchNormalization
from keras.optimizers import Adam, RMSprop
from keras.regularizers import l2
import pickle
import tensorflow as tf
import socket
from flow_parsers import *
from testers import *
from classifier import Classifier


class FlowWatcher(PatternMatchingEventHandler):
    patterns = []

    def __init__(self, classifier, flowParser, watchdir, watchFileExt, classifierTester, flowpipe):
        self.watchdir = watchdir
        pattern = '*.' + watchFileExt   # Flow file pattern to look for
        self.patterns += pattern
        self.classifier = classifier
        self.classifierTester = classifierTester
        self.flowParser = flowParser
        self.flowpipe = flowpipe

        PatternMatchingEventHandler.__init__(self)

    def process(self, event):
        """
        event.event_type 
            'modified' | 'created' | 'moved' | 'deleted'
        event.is_directory
            True | False
        event.src_path
            path/to/observed/file
        """
        # the file will be processed there
        # print event.src_path, event.event_type  # print now only for debug

        if event.event_type == 'created' or event.event_type == 'modified' and not event.is_directory:
            print 'Processing file:', event.src_path

            # Let the selected flow parser do it's job
            parsed = self.flowParser.parseFlows(event.src_path)
            if parsed is not None:
                flows, scaled_flows, feat, labels = parsed
                print 'Predicting...'
                pred = self.classifier.classify(scaled_flows[feat].as_matrix())
                # print pred
                if self.classifierTester is not None:
                    self.classifierTester.test(scaled_flows, pred, labels)
                else:
                    aggr_flows = self.aggr_flow_info(flows, pred, labels)
                    print aggr_flows
                    self.flowpipe.write(aggr_flows)
                    self.flowpipe.flush()

        return None

    def on_modified(self, event):
        self.process(event)

    def on_created(self, event):
        self.process(event)

    def aggr_flow_info(self, flows, pred, labels):
        classes = len(labels.keys())
        # Flip labels dict
        labels_inv = {v: k for k, v in labels.iteritems()}
        predlabels = np.empty((pred.shape[0],), dtype='object')
        predMat = np.argmax(pred, axis=1)
        for i in xrange(classes):
            predlabels[predMat == i] = labels_inv[i]
        predlabels[predlabels != 'BENIGN'] = 'ATTACK'
        flows['label'] = predlabels

        grpdlabel = flows.groupby(['source_ip', 'label']).agg(
            {'total_fwd_packets': np.sum}).reset_index(1)
        # print grpdlabel
        grpd = flows.groupby(['source_ip']).agg({'total_fwd_packets': np.sum})
        grpd = grpd.join(
            grpdlabel.loc[grpdlabel.label == 'ATTACK', 'total_fwd_packets'], rsuffix='_attack')

        grpd.fillna(0, inplace=True)
        grpd.loc[:, ['total_fwd_packets', 'total_fwd_packets_attack']] = grpd.loc[:, [
            'total_fwd_packets', 'total_fwd_packets_attack']].astype('int')
        aggr_flows = ''
        for row, data in grpd.iterrows():
            aggr_flows += row + '\t' + \
                str(data['total_fwd_packets']) + '\t' + \
                str(data['total_fwd_packets_attack']) + '\n'
        return aggr_flows


if __name__ == '__main__':

    # Setup args parser
    parser = argparse.ArgumentParser()
    parser.add_argument('--watchdir', action='store', dest='watchdir')
    parser.add_argument('--watchFileExt', action='store', dest='watchFileExt')
    parser.add_argument('--flowParserClass', action='store',
                        dest='flowParserClass')
    parser.add_argument('--testerClass', action='store',
                        default=None, dest='testerClass')
    parser.add_argument('--expdir', action='store', dest='expdir')
    args = parser.parse_args()

    # Get watchdir from args
    args.watchdir = os.path.abspath(os.path.expanduser(args.watchdir))
    if args.watchdir[-1] != '/':
        args.watchdir += '/'
    if not os.path.exists(args.watchdir) or not os.path.isdir(args.watchdir):
        sys.exit('Error: ' + args.watchdir +
                 ' does not exist or is not a directory')

    # Get experiment dir from args
    args.expdir = os.path.abspath(os.path.expanduser(args.expdir))
    if args.expdir[-1] != '/':
        args.expdir += '/'
    if not os.path.exists(args.expdir) or not os.path.isdir(args.expdir):
        sys.exit('Error: ' + args.expdir +
                 ' does not exist or is not a directory')

    # Init the Classifier
    clf = Classifier(args.expdir)

    # Get Flow Parser class by name
    try:
        flowParser = (globals()[args.flowParserClass])(args.expdir)
    except KeyError:
        print 'Error: No flow parser named', args.flowParserClass, 'found'
        raise

    # Get Tester class by name:
    flowPipeFile = 'flowpipe'
    flowpipe = None
    try:
        os.mkfifo(flowPipeFile)
    except OSError as oe:
        if oe.errno != errno.EEXIST:
            raise

    if args.testerClass:
        try:
            classifierTester = (globals()[args.testerClass])()
        except KeyError:
            print 'Error: No flow parser named', args.flowParserClass, 'found'
            raise
    else:
        classifierTester = None  # Means no testing to be done
        print 'Opening pipe...'
        flowpipe = open(flowPipeFile, 'w')
        print 'Pipe opened'

    # Create and schedule the Observer to look for new flow files in watchdir
    observer = Observer()
    observer.schedule(FlowWatcher(clf, flowParser, args.watchdir, args.watchFileExt,
                                  classifierTester, flowpipe), path=args.watchdir if args.watchdir else '.')
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        if flowpipe is not None:
            flowpipe.close()

    observer.join()
