import numpy as np
import json
import gzip
import os
import pandas as pd
import subprocess
import traceback
import argparse
import sys
import re


class DataParser:
    # 176
    cs = {u'c005': 0, u'c004': 1, u'c007': 2, u'0039': 3, u'0038': 4, u'c003': 5, u'c002': 6, u'0035': 7, u'0034': 8, u'0037': 9, u'0036': 10, u'c009': 11, u'c008': 12, u'0033': 13, u'0032': 14, u'c07a': 15, u'c07b': 16, u'c07c': 17, u'c07d': 18, u'0065': 19, u'c087': 21, u'c086': 22, u'c081': 23, u'c080': 24, u'c072': 25, u'c073': 26, u'c076': 27, u'c077': 28, u'0040': 29, u'0041': 30, u'0042': 31, u'feff': 32, u'0044': 33, u'0045': 34, u'0046': 35, u'0030': 36, u'c00e': 37, u'c00d': 38, u'c00f': 39, u'c00a': 40, u'c00c': 41, u'003e': 42, u'003d': 43, u'003f': 44, u'003a': 45, u'003c': 46, u'003b': 47, u'006a': 109, u'00ff': 49, u'00fd': 50, u'00fb': 51, u'00fc': 52, u'c08a': 53, u'c08b': 54, u'5600': 55, u'c05d': 56, u'c05c': 57, u'00af': 58, u'00ae': 59, u'0017': 113, u'00a7': 60, u'00a6': 61, u'00a5': 62, u'00a4': 63, u'00a3': 64, u'00a2': 65, u'00a1': 66, u'00a0': 67, u'cc13': 68, u'cc15': 69, u'cc14': 70, u'c049': 71, u'c048': 20, u'0016': 114, u'000d': 74, u'000f': 75, u'000a': 76, u'000c': 77, u'0064': 81, u'0066': 79, u'0067': 80, u'00b0': 78, u'00b1': 82, u'0062': 83, u'0063': 84, u'0060': 85, u'0061': 86, u'0068': 87, u'0069': 88, u'0004': 89, u'0005': 90,
          u'0006': 91, u'0007': 92, u'0001': 93, u'0002': 94, u'0003': 95, u'0008': 96, u'0009': 97, u'0031': 98, u'0019': 125, u'0018': 126, u'c030': 101, u'c031': 102, u'c032': 103, u'006d': 104, u'00ba': 105, u'006b': 106, u'006c': 107, u'00bd': 108, u'00be': 48, u'00c4': 110, u'00c0': 111, u'00c3': 112, u'cca9': 72, u'cca8': 73, u'0015': 115, u'0014': 116, u'0013': 117, u'0012': 118, u'0011': 119, u'0010': 120, u'c01b': 121, u'c01c': 122, u'c01a': 123, u'c01f': 124, u'c01d': 99, u'c01e': 100, u'002c': 127, u'002f': 128, u'c029': 129, u'c028': 130, u'c027': 131, u'c026': 132, u'c025': 133, u'c024': 134, u'c023': 135, u'c022': 136, u'c021': 137, u'c020': 138, u'009f': 139, u'009e': 140, u'009d': 141, u'009c': 142, u'009b': 143, u'009a': 144, u'0088': 145, u'0089': 146, u'0084': 147, u'0085': 148, u'0086': 149, u'0087': 150, u'0043': 151, u'c02f': 152, u'c02e': 153, u'c02d': 154, u'c02c': 155, u'c02b': 156, u'c02a': 157, u'c018': 158, u'c019': 159, u'001b': 160, u'001a': 161, u'c012': 162, u'c013': 163, u'c011': 164, u'c016': 165, u'c017': 166, u'c014': 167, u'008d': 168, u'008a': 169, u'008b': 170, u'008c': 171, u'0099': 172, u'0098': 173, u'0097': 174, u'0096': 175}

    # 21
    ext = {u'0017': 0, u'0023': 1, u'0015': 2, u'0000': 3, u'0012': 4, u'0005': 5, u'3374': 6, u'6a5a': 7, u'8b47': 8, u'754f': 9, u'000d': 10,
           u'ff01': 11, u'000f': 12, u'eb02': 13, u'0010': 14, u'000a': 15, u'000b': 16, u'a878': 17, u'7550': 18, u'5500': 19, u'79d1': 20}

    def __init__(self, compact=1):
        self.compact = compact

        fpkl = None
        fipt = None
        if self.compact:
            fpkl = 10 * 10
            fipt = 10 * 10
        else:
            fpkl = 60 * 60
            fipt = 30 * 30
        self.columns = ['key', 'sa', 'da', 'ts', 'te', 'dp', 'sp', 'ip', 'op', 'ib', 'ob', 'ftime'] + ['tls_cs_' + str(i + 1) for i in xrange(len(self.cs.keys()))] + ['tls_ext_' + str(i + 1) for i in xrange(len(self.ext.keys()))] + ['tls_client_key_length'] + [
            'bd_' + str(i + 1) for i in xrange(256)] + ['bd_mean', 'bd_std'] + ['fpkl_' + str(i + 1) for i in xrange(fpkl)] + ['fipt_' + str(i + 1) for i in xrange(fipt)]

    def getTLSInfo(self):

        tls_info = np.zeros(len(self.cs.keys()) + len(self.ext.keys()) + 1)

        if 'tls' in self.flow and 'cs' in self.flow['tls']:
            for c in self.flow['tls']['cs']:
                if c in self.cs:
                    tls_info[self.cs[c]] = 1

        if 'tls' in self.flow and 'tls_ext' in self.flow['tls']:
            for c in self.flow['tls']['tls_ext']:
                if c['type'] in self.ext:
                    tls_info[len(self.cs.keys()) + self.ext[c['type']]] = 1

        if 'tls' in self.flow and 'tls_client_key_length' in self.flow['tls']:
            tls_info[len(self.cs.keys()) + len(self.ext.keys())
                     ] = self.flow['tls']['tls_client_key_length']

        tls_info = list(tls_info)

        return tls_info

    #%% Byte Distribution
    def getByteDistribution(self):
        bd_mean = None
        bd_std = None
        if 'bd_mean' in self.flow:
            bd_mean = self.flow['bd_mean']
        if 'bd_std' in self.flow:
            bd_std = self.flow['bd_std']
        tmp = None
        if 'bd' in self.flow and sum(self.flow['bd']) > 0:
            tmp = map(lambda x: x /
                      float(sum(self.flow['bd'])), self.flow['bd'])
            tmp.extend([bd_mean, bd_std])
        else:
            tmp = list(np.zeros(256))
            tmp.extend([bd_mean, bd_std])

        return tmp

    #%%

    def getIndividualFlowPacketLengths(self):
        if self.compact:
            numRows = 10
            binSize = 150.0
        else:
            numRows = 60
            binSize = 25.0

        transMat = np.zeros((numRows, numRows))

        if len(self.flow['packets']) == 1:
            curPacketSize = min(
                int(self.flow['packets'][0]['b'] / binSize), numRows - 1)
            transMat[curPacketSize, curPacketSize] = 1
            return list(transMat.flatten())

        # get raw transition counts
        for i in range(1, len(self.flow['packets'])):
            prevPacketSize = min(
                int(self.flow['packets'][i - 1]['b'] / binSize), numRows - 1)
            if 'b' not in self.flow['packets'][i]:
                break
            curPacketSize = min(
                int(self.flow['packets'][i]['b'] / binSize), numRows - 1)
            transMat[prevPacketSize, curPacketSize] += 1

        # get empirical transition probabilities
        for i in range(numRows):
            if float(np.sum(transMat[i:i + 1])) != 0:
                transMat[i:i + 1] = transMat[i:i + 1] / \
                    float(np.sum(transMat[i:i + 1]))

        return list(transMat.flatten())

    #%%
    def getIndividualFlowIPTs(self):
        if self.compact:
            numRows = 10
            binSize = 50.0
        else:
            numRows = 30
            binSize = 50.0

        transMat = np.zeros((numRows, numRows))

        if len(self.flow['packets']) == 1:
            curIPT = min(int(self.flow['packets'][0]['ipt'] /
                             float(binSize)), numRows - 1)
            transMat[curIPT, curIPT] = 1
            return list(transMat.flatten())

        # get raw transition counts
        for i in range(1, len(self.flow['packets'])):
            prevIPT = min(int(self.flow['packets'][i - 1]
                              ['ipt'] / float(binSize)), numRows - 1)
            curIPT = min(int(self.flow['packets'][i]['ipt'] /
                             float(binSize)), numRows - 1)
            transMat[prevIPT, curIPT] += 1

        # get empirical transition probabilities
        for i in range(numRows):
            if float(np.sum(transMat[i:i + 1])) != 0:
                transMat[i:i + 1] = transMat[i:i + 1] / \
                    float(np.sum(transMat[i:i + 1]))

        return list(transMat.flatten())

    def getIndividualFlowMetadata(self):
        tmp = []
        # tmp_m = []
        tmp_b = 0
        if 'ib' in self.flow:
            tmp_b += self.flow['ib']
        if 'ob' in self.flow:
            tmp_b += self.flow['ob']

        key = self.flow['sa'].replace('.', '') + self.flow['da'].replace('.', '') + \
            str(int(self.flow['sp'])) + str(int(self.flow['dp'])) + str(tmp_b)
        key = str(key)

        tmp.append(key)
        tmp.append(self.flow['sa'])
        tmp.append(self.flow['da'])
        tmp.append(self.flow['ts'])
        tmp.append(self.flow['te'])
        tmp.append(float(self.flow['dp']))  # destination port
        tmp.append(float(self.flow['sp']))  # source port
        if 'ip' in self.flow:
            tmp.append(self.flow['ip'])  # inbound packets
        else:
            tmp.append(0)
            # tmp_m.append(0)
        if 'op' in self.flow:
            tmp.append(self.flow['op'])  # outbound packets
        else:
            tmp.append(0)
            # tmp_m.append(0)
        if 'ib' in self.flow:
            tmp.append(self.flow['ib'])  # inbound bytes
        else:
            tmp.append(0)
            # tmp_m.append(0)
        if 'ob' in self.flow:
            tmp.append(self.flow['ob'])  # outbound bytes
        else:
            # tmp_m.append(0)
            tmp.append(0)
        # elapsed time of flow
        if self.flow['packets'] == []:
            tmp.append(0)
        else:
            time = 0
            for packet in self.flow['packets']:
                time += packet['ipt']
            tmp.append(time)

        return tmp

    #%%
    def parseData(self, file):
        data = []
        with gzip.open(file, 'r') as fp:
            try:  # for incomplete gzip files
                i = 0
                for line in fp:
                    i += 1
                    try:
                        line = re.sub(r'{"entry_id": "[a-zA-Z0-9_\s]*?",\s,', ' ', line)
                        line = line.replace(' ls', ' "tls')
                        line = line.replace('\tls', ' "tls')
                        self.flow = json.loads(line)
                        if 'version' in self.flow or len(self.flow['packets']) == 0:
                            continue

                        flow_dat = []
                        # Get Flow Metadata
                        meta = self.getIndividualFlowMetadata()  # 10 columns
                        flow_dat += meta

                        # Get TLS Info
                        flow_dat += self.getTLSInfo()    # 198 columns

                        # Get Byte Distribution of flow
                        flow_dat += self.getByteDistribution()   # 258 columns

                        # Get Flow Packet Lengths
                        # compact 100 else 3600 columns
                        flow_dat += self.getIndividualFlowPacketLengths()

                        # Get Flow Inter Packet times
                        # compact 100 else 900 columns
                        flow_dat += self.getIndividualFlowIPTs()

                        data.append(flow_dat)

                    except Exception as e:
                        with open('errlog_' + os.path.basename(file.replace('.gz', '_')) + str(i), mode='a') as f:
                            f.write(line)
                        print e
                        traceback.print_exc()
                        continue
            except Exception as e:
                print e
                traceback.print_exc()
                return
        
        return pd.DataFrame(data, columns=self.columns)


# Setup args parser
parser = argparse.ArgumentParser()
parser.add_argument('--pcap_dir', action='store', dest='pcap_dir', required=True)
parser.add_argument('--joy_dir', action='store', dest='joy_dir', required=True)
parser.add_argument('--out_dir', action='store', dest='out_dir', default='./data')
args = parser.parse_args()


# Pcap to IntraFlow:
pcap_dir = args.pcap_dir
if not os.path.isabs(pcap_dir):
    pcap_dir = os.path.abspath(os.path.expanduser(pcap_dir))
if not os.path.exists(pcap_dir) or not os.path.isdir(pcap_dir):
    sys.exit(pcap_dir + ' is not a directory')
if pcap_dir[-1] != '/':
    pcap_dir += '/'

joy_dir = args.joy_dir
if not os.path.isabs(joy_dir):
    joy_dir = os.path.abspath(os.path.expanduser(joy_dir))
if not os.path.exists(joy_dir) or not os.path.isdir(joy_dir):
    sys.exit(joy_dir + ' is not a directory')
if joy_dir[-1] != '/':
    joy_dir += '/'

out_dir = args.out_dir
if not os.path.isabs(out_dir):
    joy_data = os.path.abspath(os.path.expanduser(out_dir))
if not os.path.exists(out_dir):
    os.makedirs(out_dir)
if out_dir[-1] != '/':
    out_dir += '/'

flow_outdir = os.path.abspath(out_dir + 'flow_records/')
if not os.path.exists(flow_outdir):
    os.makedirs(flow_outdir)
if flow_outdir[-1] != '/':
    flow_outdir += '/'

data_outdir = os.path.abspath(out_dir + 'intraflow_data/')
if not os.path.exists(data_outdir):
    os.makedirs(data_outdir)
if data_outdir[-1] != '/':
    data_outdir += '/'

pcaps = os.listdir(pcap_dir)
for pcap in pcaps:
    if '.pcap' in pcap:
        aux_resource_path = joy_dir + "resources/"
        out_file_name = pcap.replace(".pcap", "") + '.gz'
        joy = joy_dir + "bin/joy bidir=1 type=1 dist=1 entropy=1 tls=1 http=1 dhcp=1 ip_id=1 dns=1 ppi=1 zeros=1 exe=1" + \
            " output=" + out_file_name + " outdir=" + flow_outdir + \
            " aux_resource_path=" + aux_resource_path + " " + pcap_dir + pcap

        print "Converting to intraflow using: " + joy
        # Run Joy to convert to Intraflow
        subprocess.check_call(joy, stderr=subprocess.STDOUT, shell=True)


# IntraFlow to data:

flow_files = os.listdir(flow_outdir)

# Compact
fpkl = 10 * 10
fipt = 10 * 10

dataparser = DataParser()
for f in flow_files:
    if '.gz' in f:
        print 'Processing file:', flow_outdir + f
        flows = dataparser.parseData(flow_outdir + f)
        flows.to_csv(data_outdir + f.replace('.gz', '') + '.csv', index=False)
