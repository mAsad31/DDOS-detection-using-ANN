# Internal Network Security Agent


## Threats to internal networks or intranets
### Detection using flow or behaviour based techniques
    1. FTP Brute force
    2. SSH Brute force
    3. Denial of Service

### Non behaviour based detection
    1. Malware attacks (Worms, Trojans, Viruses)
    2. Malicious URL detection
    3. SQL injection
    4. Cross site scripting
    5. Phising

### Why focus on the above attacks
The attacks listed above are the most common and widespread threats to internal networks

Gaining access to confidential data of an organization requires penetrating it's network which can be easily done if the **FTP** or **SSH** services are running, are configured improperly and are accessible by an outsider. The goal is to also protect these services from within the organization.

**Malwares** can give hackers complete control over the organizational network leading to huge losses and can be spread quickly to the entire network.

**Denial of Service** attacks can cause internet inaccessibility if when huge amounts of traffic is sent to an organizations network.

**Phising** attacks can be used to send malwares to an organizations network. The product will focus on detecting malicious emails entering the network

Accessing **malicious sites** can also lead to a malware spread within the network hence this product will also focus on detecting and filtering these URLs being accessed from within the network.

The Intranet web applications are prone to **SQL injection** attacks and to prevent them clustering methods can be used to detect anomalous queries
Similary Intranet applications are also prone to **Cross site scripting**

### Detection Techniques
- Flow based features can be used to detect attacks having repititive behaviour.
- For Malicious URL detection NLP techniques will be used.
- Clustering methods can be used to model malicious non-malicious exes, scripts or codes.
- Different open source packages will be used for converting captured data into flows.
Then various deep learning models will be trained to see which combinations generalizes best.

### Architecture
- All the traffic will be routed through a machine where this product will be deployed.
- This machine will be connected directly to modem and the rest of the network connected through this machine.
- Once a basic product is developed we will see how to make it scalable for large organizational networks.
   
### Processes within this product
1. Traffic Capturer
2. Flow Convertor
3. Flow Watcher (checks for newly available flows)
4. Classifier
5. Traffic Filterer
6. Alert Generator



