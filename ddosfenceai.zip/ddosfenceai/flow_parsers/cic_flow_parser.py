from flow_parser import FlowParser
import pandas as pd
import numpy as np
from sklearn.preprocessing import *
import pickle
import os
from tools import get_ip


class CICFlowParser(FlowParser):
    lastFlow = None

    def __init__(self, expdir):
        self.expdir = expdir

        # Read experiment specific dumped pickle files
        # Features and labels
        pickledir = self.expdir + 'pickle_dump/'
        with open(pickledir + 'cols_features_labels.p', 'rb') as p:
            self.cols, self.feat, self.labels = pickle.load(p)

        with open(os.path.abspath(os.path.expanduser('experiments')) + '/columns.p', 'rb') as p:
            self.cols = pickle.load(p)

        # MinMaxScaler
        with open(pickledir + 'min_max_data.p', 'rb') as p:
            self.min_max_scaler = pickle.load(p)

        self.classes = len(self.labels.keys())

    def parseFlows(self, file):

        # Read CSV file
        data = pd.read_csv(file)
        # Modify column names according to the training data colnames
        data.columns = self.cols

        # Fix types
        data.loc[:, ['flow_bytes', 'flow_packets']] = data.loc[:,
                                                               ['flow_bytes', 'flow_packets']].astype('float64')

        # Get the current ip
        data = data[data.destination_ip == get_ip()]
        
        # Read new flows only
        newFlows = None
        if data.shape[0] != 0:
            if self.lastFlow is None:
                newFlows = data
                self.lastFlow = data.iloc[-1, :]
            elif not ((self.lastFlow == data.iloc[-1, :]).all()):
                for i in range(data.shape[0] - 1, -1, -1):
                    if (data.iloc[i, :] == self.lastFlow).all():
                        break
                    if newFlows is None:
                        newFlows = data.iloc[i, :].to_frame().transpose()
                    else:
                        # print newFlows
                        newFlows = newFlows.append(
                            data.iloc[i, :].to_frame().transpose(), ignore_index=True)
                self.lastFlow = data.iloc[-1, :]
            else:
                return None

        else:
            return None

        # Display flows
        print newFlows[['source_ip', 'source_port', 'destination_ip', 'destination_port']]
        print 'Processing', newFlows.shape[0], 'flows...'

        # Drop NaNs and Infs
        mask = (newFlows[self.feat].isnull().any(axis=1) | (
            newFlows[self.feat] == float('Inf')).any(axis=1))
        print 'Dropping %d rows where values are either NaN or Inf' % (mask.sum())
        print '\n'
        newFlows = newFlows[~mask]

        # Scaling only Numerical features
        num_feat = self.feat
        scaled_flows = newFlows.copy()
        # MinMax Scale data
        scaled_flows[num_feat] = pd.DataFrame(self.min_max_scaler.transform(
            scaled_flows[num_feat].as_matrix()), columns=num_feat)

        return newFlows, scaled_flows, self.feat, self.labels
