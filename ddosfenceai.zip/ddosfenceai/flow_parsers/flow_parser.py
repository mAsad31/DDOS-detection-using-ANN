import numpy as np
import pandas as pd
import os
import gzip
import json

class FlowParser:
    
    def parseFlows(self, file):
        raise NotImplementedError('Must be implemented')

