from tester import *
import numpy as np


class BinaryClassCICTester(Tester):

    def __init__(self):
        self.config = {
            'attackerIP': '192.168.1.8',  # Set accordingly
            'victimIP': '192.168.1.5',   # Self IP
            'victimPort': 80
        }

    def assignLabels(self, flows, pred, labels):
        # # Separate benign and attack prediction probabilities
        # benign = pred[:, 0]
        # attack = pred[:, 1]

        # # Create mask
        # mask = np.zeros((pred.shape[0],), dtype='bool')
        # # Attack is true class so where probability of attack >= benign place True
        # mask[np.where(attack >= benign)[0]] = True

        # # Create predicted labels array
        # predlabels = np.empty((pred.shape[0],), dtype='object')
        # predlabels[mask] = 'ATTACK'
        # predlabels[~mask] = 'BENIGN'

        # # Create numeric predicted labels array
        # predMat = np.zeros((pred.shape[0], ), dtype='int')
        # predMat[mask] = 1

        # # Create actual labels array
        # truelabels = np.empty((pred.shape[0], ), dtype='object')

        # # Create mask representing actual attack flows
        # attackmask = ((flows['source_ip'] == self.config['attackerIP']) & (flows['destination_ip'] == self.config['victimIP']) & (
        #     flows['destination_port'] == self.config['victimPort'])).as_matrix()

        # truelabels[attackmask] = 'ATTACK'
        # truelabels[~attackmask] = 'BENIGN'

        # # Create numeric actual labels array
        # trueMat = np.zeros((pred.shape[0], ), dtype='int')
        # trueMat[attackmask] = 1
        classes = len(labels.keys())
        # Flip labels dict
        labels_inv = {v: k for k, v in labels.iteritems()}
        predlabels = np.empty((pred.shape[0],), dtype='object')
        predMat = np.argmax(pred, axis=1)
        for i in xrange(classes):
            predlabels[predMat == i] = labels_inv[i]

        truelabels = np.empty((pred.shape[0], ), dtype='object')
        # Create mask representing actual attack flows
        attackmask = ((flows['source_ip'] == self.config['attackerIP']) & (flows['destination_ip'] == self.config['victimIP']) & (flows['destination_port'] == self.config['victimPort'])).as_matrix()
        truelabels[attackmask] = labels_inv[3]  # 3 represents HULK
        truelabels[~attackmask] = labels_inv[0]  # 0 represents BENIGN

        trueMat = np.zeros((pred.shape[0], ), dtype='int')
        trueMat[attackmask] = 3  # Hulk

        return predlabels, truelabels, predMat, trueMat
