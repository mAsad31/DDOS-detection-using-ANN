import numpy as np
import pandas as pd
import os
import gzip
import json
from tools import get_ip
from sklearn.metrics import f1_score

def print_confusion_matrix(plabels,tlabels):
    """
        functions print the confusion matrix for the different classes
        to find the error...
        
        Input:
        -----------
        plabels: predicted labels for the classes...
        tlabels: true labels for the classes
        
        code from: http://stackoverflow.com/questions/2148543/how-to-write-a-confusion-matrix-in-python
    """
    plabels = pd.Series(np.squeeze(plabels))
    tlabels = pd.Series(np.squeeze(tlabels))
    
    # draw a cross tabulation...
    df_confusion = pd.crosstab(tlabels,plabels, rownames=['Actual'], colnames=['Predicted'], margins=True)
    
    #print df_confusion
    return df_confusion


class Tester:
    config = None

    def test(self, flows, pred, labels):
        # Get labels
        predlabels, truelabels, predMat, trueMat = self.assignLabels(flows, pred, labels)

        print 'Test Results:'
        score = f1_score(trueMat, predMat, average='micro')
        print 'F1 Score:', score
        print 'Confusion Matrix:'
        print print_confusion_matrix(predlabels, truelabels)

    def assignLabels(self, flows, pred, labels):
        raise NotImplementedError('Must be implemented')
