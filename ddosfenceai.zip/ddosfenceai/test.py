import pickle
import pandas as pd
import numpy as np
data = pd.read_csv(
    '/home/talhajavaid32/CICFlowMeter-3.0/bin/data/daily/2018-03-06_Flow.csv')
data.columns = data.columns.str.lower().str.strip().str.replace(
    ' ', '_').str.replace('/s', '').str.replace('/', '_').str.replace('.', '_').str.replace('src', 'source').str.replace('dst', 'destination').str.replace('tot', 'total').str.replace('pkts', 'packets').str.replace('pkt', 'packet').str.replace('bwd', 'backward').str.replace('totallen', 'total_length_of').str.replace('fwd', 'forward').str.replace('packet_len', 'packet_length').str.replace('byts', 'bytes').str.replace('header_len', 'header_length').str.replace('min_packet_length', 'packet_length_min').str.replace('packet_length_var', 'packet_length_variance').str.replace('cnt', 'count').str.replace('', 'average_packet_size')
d = list(data.columns)
l = pickle.load(open('/home/talhajavaid32/Desktop/columnsdump.p', 'rb'))

for i in range(len(l)):
    l[i] = l[i].replace('bwd', 'backward')
    l[i] = l[i].replace('fwd', 'forward')
    l[i] = l[i].replace('min_packet_length', 'packet_length_min')
    l[i] = l[i].replace('max_packet_length', 'packet_length_max')
    # print l[i]
# for i in range(len(d)):
#     print d[i]


# l[1] = 'src_ip'
# l[3] = 'dst_ip'
# l[2] = 'src_port'
# l[4] = 'dst_port'
for i in range(len(l)):
    if d[i] != l[i]:
        print 'Where l is', l[i], 'd is', d[i]
        break

# print len(d)
# print len(l)
# print d == l
